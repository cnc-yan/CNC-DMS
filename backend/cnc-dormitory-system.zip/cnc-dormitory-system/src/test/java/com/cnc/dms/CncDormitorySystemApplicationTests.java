package com.cnc.dms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CncDormitorySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
