package com.cnc.dms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CncDormitorySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CncDormitorySystemApplication.class, args);
	}

}
